package com.example.app2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText num1,num2;
        Button add;
        TextView res;

        num1 = findViewById(R.id.editTextTextPersonName);
        num2 = findViewById(R.id.editTextTextPersonName2);
        add = findViewById(R.id.button);
        res = findViewById((R.id.textView3));

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(num1.getText().toString());
                int n2 = Integer.parseInt(num2.getText().toString());
                int sum = n1 + n2;

                res.setText(" "+ sum);

                String TAG = "MainActivity.java";
                Toast.makeText(getApplicationContext(),"SUCCESS",Toast.LENGTH_LONG).show();//for the user
                Log.d(TAG, "SUM IS : "+sum);//for developer
            }
        });


    }
}