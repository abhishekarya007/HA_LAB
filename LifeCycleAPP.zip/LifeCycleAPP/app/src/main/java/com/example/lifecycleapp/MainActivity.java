package com.example.lifecycleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("LifeStyle", "onCreate success");
    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d("LifeStyle", "onStart success");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("LifeStyle", "onStop success");
    }
    @Override
    protected void onPause(){
        super.onPause();
        Log.d("LifeStyle", "onPause success");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("LifeStyle", "onResume success");
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        Log.d("LifeStyle", "onRestart success");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("LifeStyle", "onDestroy success");
    }

}